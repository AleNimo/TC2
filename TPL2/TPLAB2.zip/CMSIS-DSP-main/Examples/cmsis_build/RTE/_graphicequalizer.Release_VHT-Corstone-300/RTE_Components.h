
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'graphicequalizer.Release+VHT-Corstone-300' 
 * Target:  'graphicequalizer.Release+VHT-Corstone-300' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "SSE300MPS3.h"



#endif /* RTE_COMPONENTS_H */
