Fixed point
===========

Fixed point extensions

.. autofunction:: cmsisdsp.fixedpoint.toQ31
.. autofunction:: cmsisdsp.fixedpoint.toQ15
.. autofunction:: cmsisdsp.fixedpoint.toQ7

.. autofunction:: cmsisdsp.fixedpoint.Q31toF32
.. autofunction:: cmsisdsp.fixedpoint.Q15toF32
.. autofunction:: cmsisdsp.fixedpoint.Q7toF32

