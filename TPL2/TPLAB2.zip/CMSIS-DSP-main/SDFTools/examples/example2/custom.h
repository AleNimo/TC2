#ifndef _CUSTOM_H_
#define HALF 0.5

#endif 

